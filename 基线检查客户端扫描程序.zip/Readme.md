## **基线检查客户端扫描程序**

#### 介绍

  基线检查客户端程序是一个自主运行的客户端基线检查扫描可执行程序，检查内容及其类型编号如下所示：

1. 设备注册REGISTER 

2. 基本信息BASE_INFO 

3. 安装的软件INSTALLED_SOFT 

4. 网络信息NETWORK_INFO 

5.  进程信息PROCESS_INFO 

6.  服务信息SERVICE_INFO 

7.  账户信息ACCOUNT_INFO 

8.  自启动信息AUTORUN_INFO 

9. 端口信息PORT_INFO 

10. 补丁信息PATCH_INFO 

11. 用户组信息GROUP_INFO 

12.  基线检查信息BASELINE_INFO 

    程序将会依次自动执行以上检测。

#### 安装教程

1. 解压zip文件到指定位置
2. 双击setup.exe文件即可安装本程序
3. 请根据安装说明进行操作，本程序安装完成后将会自动运行扫描程序

#### 使用说明

1. 请使用管理员权限运行程序
2. 安装完成后点击文件中的server.exe文件即可执行操作
3. 请不要改变安装完成后，可执行文件及其依赖文件的相对路径，以保证文件运行正常。